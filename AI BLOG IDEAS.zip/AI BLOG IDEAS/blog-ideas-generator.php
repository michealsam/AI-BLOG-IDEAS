<?php
/**
 * Plugin Name: Blog Ideas Generator
 * Description: Generate blog post ideas using OpenAI
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: blog-ideas-generator
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('BIG_VERSION', '1.0.0');
define('BIG_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BIG_PLUGIN_URL', plugin_dir_url(__FILE__));

// Initialize plugin
function big_init() {
    require_once BIG_PLUGIN_DIR . 'includes/class-admin-menu.php';
    require_once BIG_PLUGIN_DIR . 'includes/class-openai-handler.php';
    
    // Initialize classes
    new Big_Admin_Menu();
}
add_action('plugins_loaded', 'big_init');

// Activation hook
function big_activate() {
    // Set default options
    $defaults = array(
        'api_key' => '',
        'ideas_count' => 5,
        'default_prompt' => 'Generate {count} blog post ideas about {topic} for {industry}'
    );
    add_option('big_settings', $defaults);
}
register_activation_hook(__FILE__, 'big_activate'); 