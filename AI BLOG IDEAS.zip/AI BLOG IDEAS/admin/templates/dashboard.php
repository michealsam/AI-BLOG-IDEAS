<?php
if (!defined('ABSPATH')) exit;
?>

<div class="wrap blog-ideas-generator">
    <h1><?php _e('Generate Blog Ideas', 'blog-ideas-generator'); ?></h1>
    
    <div class="big-form">
        <form id="big-generator-form">
            <?php wp_nonce_field('big_generate_nonce'); ?>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="big_topic"><?php _e('Topic/Keywords', 'blog-ideas-generator'); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="big_topic" 
                               name="topic" 
                               required 
                               class="regular-text">
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="big_industry"><?php _e('Industry/Niche', 'blog-ideas-generator'); ?></label>
                    </th>
                    <td>
                        <input type="text" 
                               id="big_industry" 
                               name="industry" 
                               required 
                               class="regular-text">
                    </td>
                </tr>
            </table>
            
            <p class="submit">
                <button type="submit" class="button button-primary">
                    <?php _e('Generate Ideas', 'blog-ideas-generator'); ?>
                </button>
            </p>
        </form>
    </div>
    
    <div class="big-loading">
        <img src="<?php echo admin_url('images/spinner.gif'); ?>" alt="Loading...">
    </div>
    
    <div class="big-results" style="display: none;"></div>
</div> 