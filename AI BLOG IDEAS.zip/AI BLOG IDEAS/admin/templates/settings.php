<?php
if (!defined('ABSPATH')) exit;

// Save settings if form is submitted
if (isset($_POST['big_save_settings']) && check_admin_referer('big_settings_nonce')) {
    $settings = array(
        'api_key' => sanitize_text_field($_POST['big_api_key']),
        'ideas_count' => absint($_POST['big_ideas_count']),
        'default_prompt' => sanitize_textarea_field($_POST['big_default_prompt'])
    );
    update_option('big_settings', $settings);
    echo '<div class="notice notice-success"><p>' . __('Settings saved successfully!', 'blog-ideas-generator') . '</p></div>';
}

$settings = get_option('big_settings');
?>

<div class="wrap">
    <h1><?php _e('Blog Ideas Generator Settings', 'blog-ideas-generator'); ?></h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('big_settings_nonce'); ?>
        
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="big_api_key"><?php _e('OpenAI API Key', 'blog-ideas-generator'); ?></label>
                </th>
                <td>
                    <input type="password" 
                           id="big_api_key" 
                           name="big_api_key" 
                           value="<?php echo esc_attr($settings['api_key']); ?>" 
                           class="regular-text">
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="big_ideas_count"><?php _e('Number of Ideas', 'blog-ideas-generator'); ?></label>
                </th>
                <td>
                    <input type="number" 
                           id="big_ideas_count" 
                           name="big_ideas_count" 
                           value="<?php echo esc_attr($settings['ideas_count']); ?>" 
                           min="1" 
                           max="10">
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="big_default_prompt"><?php _e('Default Prompt Template', 'blog-ideas-generator'); ?></label>
                </th>
                <td>
                    <textarea id="big_default_prompt" 
                              name="big_default_prompt" 
                              rows="4" 
                              class="large-text"><?php echo esc_textarea($settings['default_prompt']); ?></textarea>
                </td>
            </tr>
        </table>
        
        <p class="submit">
            <input type="submit" 
                   name="big_save_settings" 
                   class="button button-primary" 
                   value="<?php _e('Save Settings', 'blog-ideas-generator'); ?>">
        </p>
    </form>
</div> 