jQuery(document).ready(function($) {
    $('#big-generator-form').on('submit', function(e) {
        e.preventDefault();
        
        const $form = $(this);
        const $loading = $('.big-loading');
        const $results = $('.big-results');
        
        // Show loading spinner
        $loading.show();
        $results.hide();
        
        // Get form data
        const formData = {
            action: 'big_generate_ideas',
            nonce: bigAjax.nonce,
            topic: $('#big_topic').val(),
            industry: $('#big_industry').val()
        };
        
        // Send AJAX request
        $.post(bigAjax.ajaxurl, formData, function(response) {
            $loading.hide();
            
            if (response.success) {
                $results.html(response.data).show();
            } else {
                $results.html('<div class="big-error">' + response.data + '</div>').show();
            }
        }).fail(function() {
            $loading.hide();
            $results.html('<div class="big-error">Failed to generate ideas. Please try again.</div>').show();
        });
    });
}); 