<?php
class Big_Admin_Menu {
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // Add AJAX handlers
        add_action('wp_ajax_big_generate_ideas', array($this, 'handle_generate_ideas'));
    }

    public function add_admin_menu() {
        add_menu_page(
            __('Blog Ideas Generator', 'blog-ideas-generator'),
            __('Blog Ideas', 'blog-ideas-generator'),
            'manage_options',
            'blog-ideas-generator',
            array($this, 'render_dashboard'),
            'dashicons-lightbulb',
            30
        );

        add_submenu_page(
            'blog-ideas-generator',
            __('Settings', 'blog-ideas-generator'),
            __('Settings', 'blog-ideas-generator'),
            'manage_options',
            'blog-ideas-generator-settings',
            array($this, 'render_settings')
        );
    }

    public function render_dashboard() {
        require_once BIG_PLUGIN_DIR . 'admin/templates/dashboard.php';
    }

    public function render_settings() {
        require_once BIG_PLUGIN_DIR . 'admin/templates/settings.php';
    }

    public function enqueue_admin_assets($hook) {
        if (!strpos($hook, 'blog-ideas-generator')) {
            return;
        }

        wp_enqueue_style(
            'big-admin-style',
            BIG_PLUGIN_URL . 'admin/css/admin-style.css',
            array(),
            BIG_VERSION
        );

        wp_enqueue_script(
            'big-admin-script',
            BIG_PLUGIN_URL . 'admin/js/admin-script.js',
            array('jquery'),
            BIG_VERSION,
            true
        );

        wp_localize_script('big-admin-script', 'bigAjax', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('big_nonce')
        ));
    }

    public function handle_generate_ideas() {
        // Verify nonce
        if (!check_ajax_referer('big_nonce', 'nonce', false)) {
            wp_send_json_error('Invalid security token');
        }

        // Verify user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        // Get and sanitize input
        $topic = sanitize_text_field($_POST['topic']);
        $industry = sanitize_text_field($_POST['industry']);

        if (empty($topic) || empty($industry)) {
            wp_send_json_error('Please provide both topic and industry');
        }

        // Initialize OpenAI handler
        $openai = new Big_OpenAI_Handler();
        
        // Generate ideas
        $result = $openai->generate_ideas($topic, $industry);

        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }

        // Format the response
        $formatted_result = nl2br(trim($result));
        wp_send_json_success($formatted_result);
    }
} 