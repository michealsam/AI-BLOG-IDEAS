<?php
class Big_OpenAI_Handler {
    private $api_key;
    
    public function __construct() {
        $settings = get_option('big_settings');
        $this->api_key = $settings['api_key'];
    }
    
    public function generate_ideas($topic, $industry, $count = 5) {
        if (empty($this->api_key)) {
            return new WP_Error('no_api_key', __('OpenAI API key is not set', 'blog-ideas-generator'));
        }

        $prompt = "Generate {$count} unique and engaging blog post ideas about {$topic} for the {$industry} industry. Format each idea as a numbered list item with a compelling title and a brief description.";

        $response = wp_remote_post('https://api.openai.com/v1/completions', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode(array(
                'model' => 'gpt-3.5-turbo-instruct',
                'prompt' => $prompt,
                'max_tokens' => 1000,
                'temperature' => 0.7,
                'n' => 1,
                'stop' => null
            )),
            'timeout' => 30
        ));

        if (is_wp_error($response)) {
            return $response;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            return new WP_Error('api_error', $body['error']['message']);
        }

        return $body['choices'][0]['text'];
    }
} 